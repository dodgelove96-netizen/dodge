import { Router, Response } from 'express';
import { dbStorage } from '../db/storage';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth';
import { requirePermission } from '../middleware/permissions';
import { PermissionKey } from '../../types/permissions';

export const userRouter = Router();

// 1. List all users (Scoped by tenant for non-superadmins)
userRouter.get('/', requireAuth, requirePermission(PermissionKey.USERS_VIEW), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    let allUsers = dbStorage.getAllUsers();

    if (!user.isSuperAdmin) {
      const allowedCompanyIds = new Set(user.assignedCompanies?.map(c => c.id) || []);
      allUsers = allUsers.filter(u => {
        const uCompanies = dbStorage.getUserCompanies(u.id);
        return uCompanies.some(c => allowedCompanyIds.has(c.id));
      });
    }

    const formatted = allUsers.map(u => {
      const roles = dbStorage.getUserRoles(u.id);
      const companies = dbStorage.getUserCompanies(u.id);
      return {
        ...u,
        roles,
        assignedCompanies: companies,
      };
    });

    res.json({
      users: formatted,
      actorScope: user.isSuperAdmin ? 'global' : 'tenant',
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to list users' });
  }
});

// 2. Create user
userRouter.post('/', requireAuth, requirePermission(PermissionKey.USERS_MANAGE), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { fullName, fullNameAr, email, phone, roleSlug, companyIds, password, isActive } = req.body;

    const created = dbStorage.createUser(
      {
        fullName,
        fullNameAr,
        email,
        phone,
        roleSlug: roleSlug || 'manager_owner',
        companyIds: companyIds || [],
        password: password || 'Password@123',
        isActive: isActive !== false,
      },
      req.user!
    );

    res.status(201).json({ user: created, message: 'User created successfully' });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to create user' });
  }
});

// 3. Update user
userRouter.put('/:id', requireAuth, requirePermission(PermissionKey.USERS_MANAGE), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { fullName, fullNameAr, phone, roleSlug, companyIds, isActive } = req.body;
    const updated = dbStorage.updateUser(
      req.params.id,
      { fullName, fullNameAr, phone, roleSlug, companyIds, isActive },
      req.user!
    );
    res.json({ user: updated, message: 'User updated successfully' });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to update user' });
  }
});

// 4. Update status
userRouter.patch('/:id/status', requireAuth, requirePermission(PermissionKey.USERS_MANAGE), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isActive } = req.body;
    const updated = dbStorage.setUserStatus(req.params.id, isActive, req.user!);
    res.json({ user: updated, message: 'User status updated successfully' });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to update user status' });
  }
});

// 5. Reset password
userRouter.post('/:id/reset-password', requireAuth, requirePermission(PermissionKey.USERS_MANAGE), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { newPassword } = req.body;
    dbStorage.resetUserPassword(req.params.id, newPassword, req.user!);
    res.json({ success: true, message: 'Password reset successfully' });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to reset password' });
  }
});

// 6. Delete user
userRouter.delete('/:id', requireAuth, requirePermission(PermissionKey.USERS_MANAGE), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const success = dbStorage.deleteUser(req.params.id, req.user!);
    res.json({ success, message: 'User removed successfully' });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to delete user' });
  }
});

// 7. Assign user to company
userRouter.post('/:id/assign-company', requireAuth, requirePermission(PermissionKey.USERS_MANAGE), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { companyId, roleSlug } = req.body;
    const success = dbStorage.assignUserToCompany(req.params.id, companyId, roleSlug, req.user!);
    res.json({ success });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to assign company' });
  }
});
