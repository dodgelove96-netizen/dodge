import { Response, NextFunction } from 'express';
import { AuthenticatedRequest } from './auth';
import { PermissionKey } from '../../types/permissions';
import { dbStorage } from '../db/storage';

export function requirePermission(requiredPerm: PermissionKey) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    if (req.user.isSuperAdmin) {
      next();
      return;
    }

    if (req.user.permissions && req.user.permissions.includes(requiredPerm)) {
      next();
      return;
    }

    // Log forbidden attempt to audit log
    dbStorage.logAudit({
      userId: req.user.id,
      companyId: req.user.primaryCompanyId || null,
      action: 'security.permission_denied',
      resource: 'system_security',
      resourceId: requiredPerm,
      status: 'FAILURE',
      ipAddress: req.ip || '127.0.0.1',
      details: {
        attemptedPermission: requiredPerm,
        userEmail: req.user.email,
        path: req.originalUrl,
      },
    });

    res.status(403).json({
      error: `Access Denied: You do not have permission '${requiredPerm}' to perform this action.`,
    });
  };
}

export function requireCompanyAccess(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.user) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  if (req.user.isSuperAdmin) {
    next();
    return;
  }

  const companyId = req.headers['x-company-id'] as string || req.params.companyId || (req.query.companyId as string);

  if (!companyId) {
    next();
    return;
  }

  const hasAccess = req.user.assignedCompanies?.some(c => c.id === companyId);
  if (!hasAccess) {
    dbStorage.logAudit({
      userId: req.user.id,
      companyId: companyId,
      action: 'security.tenant_violation',
      resource: 'company',
      resourceId: companyId,
      status: 'FAILURE',
      ipAddress: req.ip || '127.0.0.1',
      details: { attemptedCompanyId: companyId },
    });

    res.status(403).json({ error: 'Access Denied: You do not have permission to access this company workspace.' });
    return;
  }

  next();
}
