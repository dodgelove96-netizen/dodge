import fs from 'fs';
import path from 'path';

const logsDir = path.join(process.cwd(), 'logs');

// Ensure logs directory exists
try {
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
} catch {
  // Silent fallback if filesystem is read-only
}

function appendToFile(fileName: string, message: string) {
  try {
    const filePath = path.join(logsDir, fileName);
    const line = `[${new Date().toISOString()}] ${message}\n`;
    fs.appendFileSync(filePath, line, 'utf8');
  } catch {
    // Non-blocking fallback
  }
}

export const logger = {
  info: (msg: string, meta?: any) => {
    const formatted = meta ? `${msg} ${JSON.stringify(meta)}` : msg;
    console.log(`[INFO] ${formatted}`);
    appendToFile('app.log', `[INFO] ${formatted}`);
  },
  warn: (msg: string, meta?: any) => {
    const formatted = meta ? `${msg} ${JSON.stringify(meta)}` : msg;
    console.warn(`[WARN] ${formatted}`);
    appendToFile('app.log', `[WARN] ${formatted}`);
  },
  error: (msg: string, err?: any) => {
    const errDetails = err instanceof Error ? `${err.message}\n${err.stack}` : (err ? JSON.stringify(err) : '');
    const formatted = `${msg} ${errDetails}`.trim();
    console.error(`[ERROR] ${formatted}`);
    appendToFile('app.log', `[ERROR] ${formatted}`);
    appendToFile('error.log', `[ERROR] ${formatted}`);
  }
};
