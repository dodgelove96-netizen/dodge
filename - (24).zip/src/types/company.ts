import { Company, User, CompanyMetrics } from './database';

export interface CompanyWithMetrics extends Company {
  manager?: Partial<User> | null;
  metrics?: CompanyMetrics;
  taskCount?: number;
}

export type CompanyCategory = 'holding' | 'subsidiary' | 'branch' | 'affiliate' | string;
