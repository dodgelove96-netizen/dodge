import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { REPORT_EXPORT_FIELDS, ReportExportFieldKey, ReportQueryResult } from '../types/reports';

export async function generateReportPdf(
  reportData: ReportQueryResult,
  selectedFields: ReportExportFieldKey[],
  isArabic: boolean = false
) {
  const title = isArabic
    ? 'تقرير المهام والمؤشرات التشغيلية للمجموعة'
    : 'Enterprise Operations & Tasks Report';
  const subtitle = `${isArabic ? 'تاريخ التوليد:' : 'Generated on:'} ${new Date().toLocaleString()} | ${
    isArabic ? 'إجمالي السجلات:' : 'Total Records:'
  } ${reportData.filteredCount || (reportData.tasks ? reportData.tasks.length : 0)}`;

  const activeFields = REPORT_EXPORT_FIELDS.filter((f) => selectedFields.includes(f.key));
  const tableData = (reportData.data || reportData.tasks || []);

  // Create a hidden container
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.top = '0';
  container.style.width = '1200px'; // fixed wide width for landscape
  container.style.backgroundColor = '#ffffff';
  container.style.padding = '40px';
  container.style.fontFamily = 'system-ui, -apple-system, sans-serif';
  container.dir = isArabic ? 'rtl' : 'ltr';

  // Build HTML content
  let html = `
    <div style="margin-bottom: 20px;">
      <h1 style="font-size: 24px; color: #0f172a; margin-bottom: 8px;">${title}</h1>
      <p style="font-size: 14px; color: #475569; margin: 0;">${subtitle}</p>
    </div>
    <table style="width: 100%; border-collapse: collapse; font-size: 12px; text-align: ${isArabic ? 'right' : 'left'};">
      <thead>
        <tr>
          ${activeFields.map(f => `<th style="background-color: #1e293b; color: #ffffff; padding: 12px 8px; border: 1px solid #cbd5e1;">${isArabic ? f.labelAr : f.labelEn}</th>`).join('')}
        </tr>
      </thead>
      <tbody>
        ${tableData.map((row: any, i: number) => {
          const bg = i % 2 === 0 ? '#ffffff' : '#f8fafc';
          return `<tr style="background-color: ${bg};">
            ${activeFields.map(f => {
              let val = row[f.key];
              if (val === null || val === undefined) val = '-';
              if (typeof val === 'object') val = JSON.stringify(val);
              return `<td style="padding: 10px 8px; border: 1px solid #cbd5e1; color: #334155;">${val}</td>`;
            }).join('')}
          </tr>`;
        }).join('')}
      </tbody>
    </table>
  `;

  container.innerHTML = html;
  document.body.appendChild(container);

  try {
    const canvas = await html2canvas(container, {
      scale: 2, // higher resolution
      useCORS: true,
      logging: false,
    });
    
    const imgData = canvas.toDataURL('image/png');
    const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
    
    const pdfWidth = doc.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    
    doc.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    doc.save(`Operations_Report_${new Date().toISOString().substring(0, 10)}.pdf`);
  } finally {
    document.body.removeChild(container);
  }
}

