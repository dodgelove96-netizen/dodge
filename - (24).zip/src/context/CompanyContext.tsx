import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Company } from '../types/database';
import { api } from '../services/api';
import { useAuth } from './AuthContext';

export interface CompanyContextType {
  activeCompany: Company | null;
  availableCompanies: Company[];
  allCompanies: Company[];
  isLoading: boolean;
  setActiveCompany: (company: Company) => void;
  refreshCompanies: () => Promise<void>;
  createCompany: (data: Partial<Company>) => Promise<Company>;
  updateCompany: (id: string, data: Partial<Company>) => Promise<Company>;
  archiveCompany: (id: string, permanent?: boolean) => Promise<void>;
}

const CompanyContext = createContext<CompanyContextType | null>(null);

export const CompanyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [activeCompany, setActiveCompanyState] = useState<Company | null>(null);
  const [availableCompanies, setAvailableCompanies] = useState<Company[]>([]);
  const [allCompanies, setAllCompanies] = useState<Company[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const refreshCompanies = useCallback(async () => {
    if (!isAuthenticated || !user) return;
    setIsLoading(true);
    try {
      const res = await api.getCompanies();
      const companies: Company[] = res.companies || [];
      setAvailableCompanies(companies);
      setAllCompanies(companies);

      const savedActiveId = localStorage.getItem('active_company_id');
      const found = companies.find((c) => c.id === savedActiveId) || companies[0] || null;
      setActiveCompanyState(found);
      if (found) {
        localStorage.setItem('active_company_id', found.id);
      }
    } catch (err) {
      console.error('Failed to load companies:', err);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    refreshCompanies();
  }, [refreshCompanies]);

  const setActiveCompany = (company: Company) => {
    setActiveCompanyState(company);
    localStorage.setItem('active_company_id', company.id);
  };

  const createCompany = async (data: Partial<Company>): Promise<Company> => {
    const res = await api.createCompany(data);
    await refreshCompanies();
    if (res.company) {
      setActiveCompany(res.company);
    }
    return res.company;
  };

  const updateCompany = async (id: string, data: Partial<Company>): Promise<Company> => {
    const res = await api.updateCompany(id, data);
    await refreshCompanies();
    if (activeCompany?.id === id && res.company) {
      setActiveCompany(res.company);
    }
    return res.company;
  };

  const archiveCompany = async (id: string, permanent: boolean = false): Promise<void> => {
    await api.archiveCompany(id, permanent);
    await refreshCompanies();
  };

  return (
    <CompanyContext.Provider
      value={{
        activeCompany,
        availableCompanies,
        allCompanies,
        isLoading,
        setActiveCompany,
        refreshCompanies,
        createCompany,
        updateCompany,
        archiveCompany,
      }}
    >
      {children}
    </CompanyContext.Provider>
  );
};

export const useCompany = (): CompanyContextType => {
  const ctx = useContext(CompanyContext);
  if (!ctx) {
    throw new Error('useCompany must be used within a CompanyProvider');
  }
  return ctx;
};
