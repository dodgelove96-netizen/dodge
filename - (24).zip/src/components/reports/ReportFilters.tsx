import React, { useState } from 'react';
import { useI18n } from '../../i18n/I18nContext';
import { ReportFilterParams } from '../../types/reports';
import { Company, User } from '../../types/database';
import {
  Filter,
  RotateCcw,
  Search,
  Building2,
  CheckCircle2,
  AlertTriangle,
  UserCheck,
  Calendar,
  X,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

interface ReportFiltersProps {
  filters: ReportFilterParams;
  onChangeFilters: (newFilters: ReportFilterParams) => void;
  onApply: () => void;
  onReset: () => void;
  companies: Company[];
  users: User[];
  totalMatches: number;
  isLoading?: boolean;
}

export const ReportFilters: React.FC<ReportFiltersProps> = ({
  filters,
  onChangeFilters,
  onApply,
  onReset,
  companies,
  users,
  totalMatches,
  isLoading = false,
}) => {
  const { t, language } = useI18n();
  const isAr = language === 'ar';
  const [isExpanded, setIsExpanded] = useState(true);

  const handleFieldChange = (field: keyof ReportFilterParams, value: any) => {
    onChangeFilters({
      ...filters,
      [field]: value === '' ? undefined : value,
    });
  };

  const removeSingleFilter = (field: keyof ReportFilterParams) => {
    const updated = { ...filters };
    delete updated[field];
    onChangeFilters(updated);
  };

  // Build active filter badges list
  const activeBadges: Array<{ id: keyof ReportFilterParams; label: string; value: string }> = [];

  if (filters.companyId && filters.companyId !== 'all') {
    const c = companies.find(comp => comp.id === filters.companyId);
    activeBadges.push({
      id: 'companyId',
      label: t('reports.filter_company'),
      value: c ? (isAr ? c.nameAr : c.nameEn) : filters.companyId,
    });
  }

  if (filters.status && filters.status !== 'all') {
    const statusMap: Record<string, string> = {
      pending: isAr ? 'قيد الانتظار' : 'Pending',
      in_progress: isAr ? 'قيد التنفيذ' : 'In Progress',
      delayed: isAr ? 'متأخرة' : 'Delayed',
      completed: isAr ? 'مكتملة' : 'Completed',
      paused: isAr ? 'معلقة' : 'Paused',
      cancelled: isAr ? 'ملغاة' : 'Cancelled',
    };
    activeBadges.push({
      id: 'status',
      label: t('reports.filter_status'),
      value: statusMap[filters.status] || filters.status,
    });
  }

  if (filters.priority && filters.priority !== 'all') {
    const priorityMap: Record<string, string> = {
      vip: isAr ? 'أولوية قصوى (VIP)' : 'VIP Critical',
      high: isAr ? 'عالية' : 'High',
      medium: isAr ? 'متوسطة' : 'Medium',
      low: isAr ? 'منخفضة' : 'Low',
    };
    activeBadges.push({
      id: 'priority',
      label: t('reports.filter_priority'),
      value: priorityMap[filters.priority] || filters.priority,
    });
  }

  if (filters.assignedToId && filters.assignedToId !== 'all') {
    const u = users.find(usr => usr.id === filters.assignedToId);
    activeBadges.push({
      id: 'assignedToId',
      label: t('reports.filter_assigned_to'),
      value: u ? (isAr ? u.fullNameAr || u.fullName : u.fullName) : filters.assignedToId,
    });
  }

  if (filters.creatorId && filters.creatorId !== 'all') {
    const u = users.find(usr => usr.id === filters.creatorId);
    activeBadges.push({
      id: 'creatorId',
      label: t('reports.filter_created_by'),
      value: u ? (isAr ? u.fullNameAr || u.fullName : u.fullName) : filters.creatorId,
    });
  }

  if (filters.dateFrom || filters.dateTo) {
    activeBadges.push({
      id: 'dateFrom',
      label: isAr ? 'فترة الإنشاء' : 'Creation Date',
      value: `${filters.dateFrom || '...'} → ${filters.dateTo || '...'}`,
    });
  }

  if (filters.dueDateFrom || filters.dueDateTo) {
    activeBadges.push({
      id: 'dueDateFrom',
      label: isAr ? 'تاريخ الاستحقاق' : 'Due Date',
      value: `${filters.dueDateFrom || '...'} → ${filters.dueDateTo || '...'}`,
    });
  }

  if (filters.search) {
    activeBadges.push({
      id: 'search',
      label: isAr ? 'بحث' : 'Search',
      value: `"${filters.search}"`,
    });
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-6">
      {/* Header Bar */}
      <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/70">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
            <Filter className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900 text-sm">{t('reports.advanced_filters')}</span>
              {activeBadges.length > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-600 text-white">
                  {activeBadges.length} {t('reports.active_filters')}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block">{t('reports.combined_hint')}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {activeBadges.length > 0 && (
            <button
              type="button"
              onClick={onReset}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200/70 px-3 py-1.5 rounded-lg border border-slate-200 transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {t('reports.clear_filters')}
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 p-1.5 rounded-lg hover:bg-slate-200/50 transition-colors flex items-center gap-1"
          >
            <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </div>

      {/* Active Combined Filter Badges */}
      {activeBadges.length > 0 && (
        <div className="px-4 py-2.5 bg-blue-50/40 border-b border-blue-100 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-blue-900 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            {isAr ? 'الفلاتر المدمجة:' : 'Combined Filters:'}
          </span>
          {activeBadges.map(badge => (
            <span
              key={badge.id}
              className="inline-flex items-center gap-1.5 bg-white border border-blue-200 text-blue-900 px-2.5 py-1 rounded-lg text-xs font-semibold shadow-xs"
            >
              <span className="text-slate-500 font-normal">{badge.label}:</span>
              <span>{badge.value}</span>
              <button
                type="button"
                onClick={() => removeSingleFilter(badge.id)}
                className="text-slate-400 hover:text-rose-600 transition-colors p-0.5 rounded hover:bg-rose-50"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}

          <span className="ms-auto text-xs font-bold text-slate-600">
            {isAr ? `النتائج المطابقة: ${totalMatches} مهمة` : `Matches: ${totalMatches} tasks`}
          </span>
        </div>
      )}

      {/* Filters Form Controls */}
      {isExpanded && (
        <div className="p-4 space-y-4">
          {/* Row 1: Company, Status, Priority, Assigned To */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* Company Filter */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                {t('reports.filter_company')}
              </label>
              <select
                value={filters.companyId || 'all'}
                onChange={e => handleFieldChange('companyId', e.target.value)}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              >
                <option value="all">{t('reports.filter_all_companies')}</option>
                {companies.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.code} - {isAr ? c.nameAr : c.nameEn}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                {t('reports.filter_status')}
              </label>
              <select
                value={filters.status || 'all'}
                onChange={e => handleFieldChange('status', e.target.value)}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              >
                <option value="all">{t('reports.filter_all_statuses')}</option>
                <option value="pending">{isAr ? 'قيد الانتظار (Pending)' : 'Pending'}</option>
                <option value="in_progress">{isAr ? 'قيد التنفيذ (In Progress)' : 'In Progress'}</option>
                <option value="delayed">{isAr ? 'متأخرة (Delayed)' : 'Delayed'}</option>
                <option value="completed">{isAr ? 'مكتملة (Completed)' : 'Completed'}</option>
                <option value="paused">{isAr ? 'معلقة / متوقفة (Paused)' : 'Paused'}</option>
                <option value="cancelled">{isAr ? 'ملغاة (Cancelled)' : 'Cancelled'}</option>
              </select>
            </div>

            {/* Priority Filter */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-slate-400" />
                {t('reports.filter_priority')}
              </label>
              <select
                value={filters.priority || 'all'}
                onChange={e => handleFieldChange('priority', e.target.value)}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              >
                <option value="all">{t('reports.filter_all_priorities')}</option>
                <option value="vip">{isAr ? 'أولوية قصوى (VIP)' : 'VIP Critical'}</option>
                <option value="high">{isAr ? 'عالية (High)' : 'High'}</option>
                <option value="medium">{isAr ? 'متوسطة (Medium)' : 'Medium'}</option>
                <option value="low">{isAr ? 'منخفضة (Low)' : 'Low'}</option>
              </select>
            </div>

            {/* Assigned To Filter */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                {t('reports.filter_assigned_to')}
              </label>
              <select
                value={filters.assignedToId || 'all'}
                onChange={e => handleFieldChange('assignedToId', e.target.value)}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              >
                <option value="all">{t('reports.filter_all_users')}</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>
                    {isAr ? u.fullNameAr || u.fullName : u.fullName} ({u.email})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 2: Created By, Date Range, Due Date Range, Search Keyword */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 pt-2 border-t border-slate-100">
            {/* Created By */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                {t('reports.filter_created_by')}
              </label>
              <select
                value={filters.creatorId || 'all'}
                onChange={e => handleFieldChange('creatorId', e.target.value)}
                className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              >
                <option value="all">{t('reports.filter_all_users')}</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>
                    {isAr ? u.fullNameAr || u.fullName : u.fullName}
                  </option>
                ))}
              </select>
            </div>

            {/* Date Range (Created / Start) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {isAr ? 'فترة الإنشاء / البدء' : 'Creation / Start Date'}
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={filters.dateFrom || ''}
                  onChange={e => handleFieldChange('dateFrom', e.target.value)}
                  className="w-1/2 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="من"
                />
                <span className="text-slate-400 text-xs">→</span>
                <input
                  type="date"
                  value={filters.dateTo || ''}
                  onChange={e => handleFieldChange('dateTo', e.target.value)}
                  className="w-1/2 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="إلى"
                />
              </div>
            </div>

            {/* Due Date Range */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {isAr ? 'تاريخ الاستحقاق المحدد' : 'Due Date Range'}
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="date"
                  value={filters.dueDateFrom || ''}
                  onChange={e => handleFieldChange('dueDateFrom', e.target.value)}
                  className="w-1/2 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="من"
                />
                <span className="text-slate-400 text-xs">→</span>
                <input
                  type="date"
                  value={filters.dueDateTo || ''}
                  onChange={e => handleFieldChange('dueDateTo', e.target.value)}
                  className="w-1/2 text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-slate-700 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="إلى"
                />
              </div>
            </div>

            {/* Keyword Search */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <Search className="w-3.5 h-3.5 text-slate-400" />
                {isAr ? 'بحث بالنص أو المعرف' : 'Keyword or Code'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={filters.search || ''}
                  onChange={e => handleFieldChange('search', e.target.value)}
                  placeholder={t('reports.filter_search')}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl ps-8 pe-3 py-2 text-slate-800 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute start-2.5 top-2.5 pointer-events-none" />
                {filters.search && (
                  <button
                    type="button"
                    onClick={() => handleFieldChange('search', undefined)}
                    className="absolute end-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
