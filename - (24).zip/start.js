import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const serverPath = path.join(__dirname, 'dist', 'server.cjs');

console.log('Starting local server using safe relative paths on Port 2026...');
const child = spawn('node', [serverPath], {
  stdio: 'inherit',
  shell: false,
  windowsHide: false,
  env: { ...process.env, PORT: '2026' }
});

child.on('error', (err) => {
  console.error('Failed to start server:', err);
});

child.on('exit', (code, signal) => {
  console.log(`Server process exited with code ${code}`);
});
