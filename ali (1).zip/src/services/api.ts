import { Company, Role, Permission, UserDashboardConfig, SystemAboutSettings, BackupConfig, BackupMetadata } from '../types/database';
import { PermissionKey } from '../types/permissions';
import { AuthUser, LoginResponse } from '../types/auth';
import { ReportType, ReportFilterParams, ReportQueryResult } from '../types/reports';

class ApiService {
  private getHeaders(): HeadersInit {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    const token = localStorage.getItem('auth_token');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const activeCompanyId = localStorage.getItem('active_company_id');
    if (activeCompanyId) {
      headers['X-Company-Id'] = activeCompanyId;
    }

    return headers;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const response = await fetch(endpoint, {
      ...options,
      credentials: 'include', // Support HTTP-Only session cookies
      headers: {
        ...this.getHeaders(),
        ...(options.headers || {}),
      },
    });

    if (!response.ok) {
      let errorMessage = `HTTP Error ${response.status}: ${response.statusText}`;
      let errorData: any = {};
      try {
        errorData = await response.json();
        if (errorData.error) {
          errorMessage = errorData.error;
        }
      } catch {
        // use default error message
      }
      const err = new Error(errorMessage) as any;
      err.status = response.status;
      err.data = errorData;
      throw err;
    }

    return response.json();
  }

  // --- Auth Endpoints ---
  async login(email: string, password?: string): Promise<LoginResponse> {
    return this.request<LoginResponse>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  async logout(): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/api/auth/logout', {
      method: 'POST',
    });
  }

  async getMe(): Promise<{ user: AuthUser }> {
    return this.request<{ user: AuthUser }>('/api/auth/me');
  }

  async forgotPassword(email: string): Promise<{ success: boolean; message: string; resetToken?: string }> {
    return this.request('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  }

  async resetPasswordWithToken(data: { email: string; newPassword: string; resetToken: string }): Promise<{ success: boolean; message: string }> {
    return this.request('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getSecurityStatus(): Promise<any> {
    return this.request('/api/auth/security-status');
  }

  async switchPersona(persona: 'super_admin' | 'admin' | 'manager_owner'): Promise<LoginResponse> {
    return this.request<LoginResponse>('/api/auth/switch-persona', {
      method: 'POST',
      body: JSON.stringify({ persona }),
    });
  }

  // --- Companies Endpoints ---
  async getCompanies(): Promise<{ companies: Company[]; isGlobalScope: boolean; totalCount: number }> {
    return this.request<{ companies: Company[]; isGlobalScope: boolean; totalCount: number }>('/api/companies');
  }

  async getCompany(id: string): Promise<{ company: Company }> {
    return this.request<{ company: Company }>(`/api/companies/${id}`);
  }

  async createCompany(data: Partial<Company>): Promise<{ company: Company }> {
    return this.request<{ company: Company }>('/api/companies', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateCompany(id: string, data: Partial<Company>): Promise<{ company: Company }> {
    return this.request<{ company: Company }>(`/api/companies/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async archiveCompany(id: string, permanent = false): Promise<{ success: boolean; message: string; company?: Company }> {
    return this.request<{ success: boolean; message: string; company?: Company }>(
      `/api/companies/${id}${permanent ? '?permanent=true' : ''}`,
      { method: 'DELETE' }
    );
  }

  async getCompanyDashboard(companyId: string): Promise<{ company: any; metrics: any; recentTasks: any[]; reports: any }> {
    return this.request<{ company: any; metrics: any; recentTasks: any[]; reports: any }>(`/api/companies/${companyId}/dashboard`);
  }

  async getCompanyTasks(companyId: string): Promise<{ tasks: any[] }> {
    return this.request<{ tasks: any[] }>(`/api/companies/${companyId}/tasks`);
  }

  async createCompanyTask(companyId: string, data: any): Promise<{ task: any }> {
    return this.request<{ task: any }>(`/api/companies/${companyId}/tasks`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateCompanyTask(companyId: string, taskId: string, data: any): Promise<{ task: any }> {
    return this.request<{ task: any }>(`/api/companies/${companyId}/tasks/${taskId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async getCompanyReports(companyId: string): Promise<{ reports: any }> {
    return this.request<{ reports: any }>(`/api/companies/${companyId}/reports`);
  }

  async getCompanyFiles(companyId: string): Promise<{ files: any[] }> {
    return this.request<{ files: any[] }>(`/api/companies/${companyId}/files`);
  }

  async addCompanyFile(companyId: string, fileData: any): Promise<{ file: any }> {
    return this.request<{ file: any }>(`/api/companies/${companyId}/files`, {
      method: 'POST',
      body: JSON.stringify(fileData),
    });
  }

  async deleteCompanyFile(companyId: string, fileId: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/api/companies/${companyId}/files/${fileId}`, {
      method: 'DELETE',
    });
  }

  async getCompanyActivity(companyId: string, limit = 50): Promise<{ activity: any[] }> {
    return this.request<{ activity: any[] }>(`/api/companies/${companyId}/activity?limit=${limit}`);
  }

  // --- Roles & Granular Permissions Endpoints ---
  async getRoles(): Promise<{ roles: Role[] }> {
    return this.request<{ roles: Role[] }>('/api/roles');
  }

  async getPermissions(): Promise<{ permissions: Permission[] }> {
    return this.request<{ permissions: Permission[] }>('/api/roles/permissions');
  }

  async getRolePermissions(roleId: string): Promise<{ roleId: string; permissions: PermissionKey[] }> {
    return this.request<{ roleId: string; permissions: PermissionKey[] }>(`/api/roles/${roleId}/permissions`);
  }

  async updateRolePermissions(roleId: string, permissions: PermissionKey[]): Promise<{ roleId: string; permissions: PermissionKey[] }> {
    return this.request<{ roleId: string; permissions: PermissionKey[] }>(`/api/roles/${roleId}/permissions`, {
      method: 'PUT',
      body: JSON.stringify({ permissions }),
    });
  }

  // --- Users Endpoints ---
  async getUsers(): Promise<{ users: any[]; actorScope: string }> {
    return this.request<{ users: any[]; actorScope: string }>('/api/users');
  }

  async createUser(data: {
    fullName: string;
    fullNameAr?: string;
    email: string;
    phone?: string;
    roleSlug: string;
    companyIds: string[];
    password?: string;
    isActive?: boolean;
  }): Promise<{ user: any; message: string }> {
    return this.request<{ user: any; message: string }>('/api/users', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateUser(
    userId: string,
    data: {
      fullName?: string;
      fullNameAr?: string;
      phone?: string;
      roleSlug?: string;
      companyIds?: string[];
      isActive?: boolean;
    }
  ): Promise<{ user: any; message: string }> {
    return this.request<{ user: any; message: string }>(`/api/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async setUserStatus(userId: string, isActive: boolean): Promise<{ user: any; message: string }> {
    return this.request<{ user: any; message: string }>(`/api/users/${userId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ isActive }),
    });
  }

  async resetUserPassword(userId: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/api/users/${userId}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    });
  }

  async deleteUser(userId: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/api/users/${userId}`, {
      method: 'DELETE',
    });
  }

  async assignUserToCompany(userId: string, companyId: string, roleSlug: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api/users/${userId}/assign-company`, {
      method: 'POST',
      body: JSON.stringify({ companyId, roleSlug }),
    });
  }

  // --- Security Testing Suite ---
  async runSecuritySuite(): Promise<any> {
    return this.request('/api/security-test/run', {
      method: 'POST',
    });
  }

  // --- Audit Logs ---
  async getAuditLogs(companyId?: string, limit = 100): Promise<{ logs: any[] }> {
    const query = new URLSearchParams();
    if (companyId) query.set('companyId', companyId);
    query.set('limit', limit.toString());
    return this.request<{ logs: any[] }>(`/api/audit-logs?${query.toString()}`);
  }

  async queryAuditLogs(filters: {
    search?: string;
    dateFrom?: string;
    dateTo?: string;
    userFilter?: string;
    actionFilter?: string;
    entityFilter?: string;
    companyId?: string;
    limit?: number;
    offset?: number;
  }): Promise<{
    logs: any[];
    totalCount: number;
    todayCount: number;
    securityCount: number;
    uniqueUsers: Array<{ id: string; name: string; email: string }>;
    availableActions: string[];
    availableEntities: string[];
  }> {
    const params = new URLSearchParams();
    if (filters.search) params.set('search', filters.search);
    if (filters.dateFrom) params.set('dateFrom', filters.dateFrom);
    if (filters.dateTo) params.set('dateTo', filters.dateTo);
    if (filters.userFilter && filters.userFilter !== 'all') params.set('userFilter', filters.userFilter);
    if (filters.actionFilter && filters.actionFilter !== 'all') params.set('actionFilter', filters.actionFilter);
    if (filters.entityFilter && filters.entityFilter !== 'all') params.set('entityFilter', filters.entityFilter);
    if (filters.companyId && filters.companyId !== 'all') params.set('companyId', filters.companyId);
    if (filters.limit) params.set('limit', filters.limit.toString());
    if (filters.offset) params.set('offset', filters.offset.toString());

    return this.request(`/api/audit-logs?${params.toString()}`);
  }

  // --- Notification Center ---
  async getNotifications(options?: { unreadOnly?: boolean; type?: string; limit?: number }): Promise<{
    notifications: any[];
    unreadCount: number;
  }> {
    const params = new URLSearchParams();
    if (options?.unreadOnly) params.set('unreadOnly', 'true');
    if (options?.type && options.type !== 'all') params.set('type', options.type);
    if (options?.limit) params.set('limit', options.limit.toString());

    return this.request(`/api/notifications?${params.toString()}`);
  }

  async getUnreadNotificationsCount(): Promise<{ unreadCount: number }> {
    return this.request('/api/notifications/unread-count');
  }

  async markNotificationAsRead(id: string, isRead = true): Promise<{ success: boolean; id: string; isRead: boolean }> {
    return this.request(`/api/notifications/${id}/read`, {
      method: 'PATCH',
      body: JSON.stringify({ isRead }),
    });
  }

  async markAllNotificationsAsRead(): Promise<{ success: boolean; markedReadCount: number }> {
    return this.request('/api/notifications/read-all', {
      method: 'POST',
    });
  }

  async deleteNotification(id: string): Promise<{ success: boolean; message: string }> {
    return this.request(`/api/notifications/${id}`, {
      method: 'DELETE',
    });
  }

  // --- Secure Attachments ---
  async downloadTaskAttachment(taskId: string, attachmentId: string): Promise<{ success: boolean; attachment: any }> {
    return this.request(`/api/tasks/${taskId}/attachments/${attachmentId}/download`);
  }

  async deleteTaskAttachment(taskId: string, attachmentId: string): Promise<{ message: string }> {
    return this.request(`/api/tasks/${taskId}/attachments/${attachmentId}`, {
      method: 'DELETE',
    });
  }

  // --- Schema Introspection ---
  async getSchemaMetadata(): Promise<{
    totalEntities: number;
    entities: any[];
    sqlSchema: string;
    drizzleSchema: string;
  }> {
    return this.request('/api/system/schema');
  }

  // --- Dashboard Analytics & Customization Endpoints ---
  async getDashboardMetrics(companyFilter?: string): Promise<{
    config: UserDashboardConfig;
    widgets: Record<string, number>;
    charts: {
      tasks_by_company: any[];
      tasks_by_status: any[];
      tasks_by_priority: any[];
      tasks_by_user: any[];
      tasks_over_time: any[];
    };
    recentTasks: any[];
    allowedCompanies: Array<{ id: string; code: string; nameEn: string; nameAr: string }>;
  }> {
    const query = companyFilter && companyFilter !== 'all' ? `?companyFilter=${encodeURIComponent(companyFilter)}` : '';
    return this.request(`/api/dashboard/metrics${query}`);
  }

  async getDashboardConfig(): Promise<{ config: UserDashboardConfig }> {
    return this.request('/api/dashboard/config');
  }

  async getAllDashboardConfigs(): Promise<{ configs: UserDashboardConfig[]; users: any[] }> {
    return this.request('/api/dashboard/configs');
  }

  async saveDashboardConfig(
    userId: string,
    data: {
      widgets: any[];
      charts: any[];
      companyIds: string[];
      showRecentTasks?: boolean;
    }
  ): Promise<{ config: UserDashboardConfig; message: string }> {
    return this.request(`/api/dashboard/config/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async resetDashboardConfig(userId: string): Promise<{ config: UserDashboardConfig; message: string }> {
    return this.request(`/api/dashboard/config/reset/${userId}`, {
      method: 'POST',
    });
  }

  // --- Reports System Endpoints ---
  async queryReports(reportType: ReportType, filters: ReportFilterParams = {}): Promise<ReportQueryResult> {
    const params = new URLSearchParams();
    params.set('reportType', reportType);
    if (filters.companyId && filters.companyId !== 'all') params.set('companyId', filters.companyId);
    if (filters.status && filters.status !== 'all') params.set('status', filters.status);
    if (filters.priority && filters.priority !== 'all') params.set('priority', filters.priority);
    if (filters.assignedToId && filters.assignedToId !== 'all') params.set('assignedToId', filters.assignedToId);
    if (filters.creatorId && filters.creatorId !== 'all') params.set('creatorId', filters.creatorId);
    if (filters.dateFrom) params.set('dateFrom', filters.dateFrom);
    if (filters.dateTo) params.set('dateTo', filters.dateTo);
    if (filters.dueDateFrom) params.set('dueDateFrom', filters.dueDateFrom);
    if (filters.dueDateTo) params.set('dueDateTo', filters.dueDateTo);
    if (filters.search) params.set('search', filters.search);

    return this.request<ReportQueryResult>(`/api/reports/query?${params.toString()}`);
  }

  async exportReportExcel(payload: {
    reportType: ReportType;
    filters: ReportFilterParams;
    selectedFields: string[];
    language: 'ar' | 'en';
  }): Promise<void> {
    const response = await fetch('/api/reports/export/excel', {
      method: 'POST',
      credentials: 'include',
      headers: {
        ...this.getHeaders(),
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Export failed with HTTP ${response.status}`);
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `report_${payload.reportType}_${new Date().toISOString().substring(0, 10)}.xlsx`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  async exportReportPdfData(payload: {
    reportType: ReportType;
    filters: ReportFilterParams;
    selectedFields: string[];
  }): Promise<{ success: boolean; data: ReportQueryResult }> {
    return this.request<{ success: boolean; data: ReportQueryResult }>('/api/reports/export/pdf-data', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  // --- System About & Copyright Metadata ---
  async getSystemAbout(): Promise<{ success: boolean; about: SystemAboutSettings }> {
    return this.request<{ success: boolean; about: SystemAboutSettings }>('/api/system/about');
  }

  async updateSystemAbout(payload: Partial<SystemAboutSettings>): Promise<{ success: boolean; message: string; about: SystemAboutSettings }> {
    return this.request<{ success: boolean; message: string; about: SystemAboutSettings }>('/api/system/about', {
      method: 'PUT',
      body: JSON.stringify(payload),
    });
  }

  // --- Dynamic Permissions Management ---
  async createPermission(data: {
    key: string;
    module: string;
    nameEn: string;
    nameAr: string;
    descriptionEn?: string;
    descriptionAr?: string;
  }): Promise<{ success: boolean; message: string; permission: Permission }> {
    return this.request<{ success: boolean; message: string; permission: Permission }>('/api/roles/permissions', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async deletePermission(key: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/api/roles/permissions/${encodeURIComponent(key)}`, {
      method: 'DELETE',
    });
  }

  // --- System Reset to Zero (Super Admin) ---
  async resetSystemToZero(): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/api/system/reset-zero', {
      method: 'POST',
    });
  }

  // --- System Backup & Restore ---
  async downloadBackupFile(pathMode: 'auto' | 'manual' = 'auto', customPath?: string): Promise<void> {
    const token = localStorage.getItem('auth_token');
    const query = new URLSearchParams({ pathMode });
    if (customPath) query.set('customPath', customPath);

    const response = await fetch(`/api/system/backup?${query.toString()}`, {
      method: 'GET',
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to download backup file');
    }

    const blob = await response.blob();
    const disposition = response.headers.get('Content-Disposition');
    let filename = `enterprise_backup_${new Date().toISOString().substring(0, 10)}.json`;
    if (disposition && disposition.includes('filename=')) {
      const match = disposition.match(/filename="?([^"]+)"?/);
      if (match && match[1]) filename = match[1];
    }

    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  async createBackup(pathMode: 'auto' | 'manual' = 'auto', customPath?: string, type: 'manual' | 'auto' = 'manual'): Promise<{
    success: boolean;
    message: string;
    metadata: BackupMetadata;
    payload: any;
  }> {
    return this.request<{ success: boolean; message: string; metadata: BackupMetadata; payload: any }>('/api/system/backup', {
      method: 'POST',
      body: JSON.stringify({ pathMode, customPath, type }),
    });
  }

  async restoreBackup(backupData: any): Promise<{ success: boolean; message: string; stats?: any }> {
    return this.request<{ success: boolean; message: string; stats?: any }>('/api/system/restore', {
      method: 'POST',
      body: JSON.stringify({ backupData }),
    });
  }

  async getBackupConfig(): Promise<{ success: boolean; config: BackupConfig; history: BackupMetadata[] }> {
    return this.request<{ success: boolean; config: BackupConfig; history: BackupMetadata[] }>('/api/system/backup-config');
  }

  async updateBackupConfig(config: Partial<BackupConfig>): Promise<{ success: boolean; message: string; config: BackupConfig }> {
    return this.request<{ success: boolean; message: string; config: BackupConfig }>('/api/system/backup-config', {
      method: 'PUT',
      body: JSON.stringify(config),
    });
  }
}

export const api = new ApiService();
