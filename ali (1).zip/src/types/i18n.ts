export type Language = 'ar' | 'en';
export type Direction = 'rtl' | 'ltr';

export interface I18nContextType {
  language: Language;
  direction: Direction;
  setLanguage: (lang: Language) => void;
  t: (key: string, defaultText?: string) => string;
}
