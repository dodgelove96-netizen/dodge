import { PermissionKey } from './permissions';

export type RoleSlug = 'super_admin' | 'admin' | 'manager_owner';

export interface User {
  id: string;
  email: string;
  passwordHash?: string;
  fullName: string;
  fullNameAr?: string;
  phone?: string;
  avatarUrl?: string;
  isActive: boolean;
  isArchived?: boolean;
  lastLoginAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Role {
  id: string;
  slug: RoleSlug | string;
  nameEn: string;
  nameAr: string;
  descriptionEn: string;
  descriptionAr: string;
  isSystem: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Permission {
  id: string;
  key: PermissionKey;
  module: string;
  nameEn: string;
  nameAr: string;
  descriptionEn: string;
  descriptionAr: string;
  createdAt: string;
}

export interface UserRole {
  id: string;
  userId: string;
  roleId: string;
  companyId?: string | null; // null for Super Admin (global), or company-specific role
  createdAt: string;
}

export interface RolePermission {
  id: string;
  roleId: string;
  permissionKey: PermissionKey;
  createdAt: string;
}

export interface Company {
  id: string;
  nameEn: string;
  nameAr: string;
  code: string; // unique short code like "ACME", "TECH_CO"
  industryEn?: string;
  industryAr?: string;
  logoUrl?: string;
  descriptionEn?: string;
  descriptionAr?: string;
  managerId?: string;
  contactEmail?: string;
  contactPhone?: string;
  website?: string;
  address?: string;
  currency: string;
  country: string;
  isActive: boolean;
  isArchived?: boolean;
  settings?: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface CompanyMetrics {
  totalTasks: number;
  completedTasks: number;
  pendingTasks: number;
  inProgressTasks: number;
  delayedTasks: number;
  pausedTasks: number;
  vipTasks: number;
  overdueTasks: number;
  completionRate: number;
}

export interface CompanyFile {
  id: string;
  companyId: string;
  name: string;
  category: 'contract' | 'registration' | 'financial' | 'policy' | 'other';
  fileSize: number;
  mimeType: string;
  fileUrl: string;
  uploaderId: string;
  uploaderName?: string;
  createdAt: string;
}

export interface UserCompany {
  id: string;
  userId: string;
  companyId: string;
  isPrimary: boolean;
  assignedRoleSlug: RoleSlug;
  createdAt: string;
}

export type TaskStatusSlug = 'pending' | 'in_progress' | 'delayed' | 'completed' | 'paused' | 'cancelled';
export type TaskPrioritySlug = 'vip' | 'high' | 'medium' | 'low';

export interface TaskStatus {
  id: string;
  companyId?: string | null;
  nameEn: string;
  nameAr: string;
  slug: TaskStatusSlug | string;
  color: string;
  orderIndex: number;
  isDefault: boolean;
  isFinal: boolean;
  createdAt: string;
}

export interface TaskPriority {
  id: string;
  nameEn: string;
  nameAr: string;
  slug: TaskPrioritySlug | string;
  color: string;
  orderIndex: number;
  createdAt: string;
}

export type CustomFieldType =
  | 'text'
  | 'long_text'
  | 'number'
  | 'date'
  | 'date_time'
  | 'dropdown'
  | 'multi_select'
  | 'checkbox'
  | 'radio'
  | 'user_selector'
  | 'company_selector'
  | 'file_upload';

export interface CustomField {
  id: string;
  nameAr: string;
  nameEn: string;
  fieldKey: string;
  type: CustomFieldType;
  options?: string[];
  required: boolean;
  defaultValue?: any;
  visibility: 'all' | 'internal' | 'admin_only';
  companyIds: string[]; // empty = all companies
  roleSlugs: string[]; // empty = all roles
  sortOrder: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TaskTimelineEvent {
  id: string;
  taskId: string;
  type: 'created' | 'assigned' | 'status_changed' | 'priority_changed' | 'note_added' | 'attachment_added' | 'updated' | 'completed';
  userId: string;
  userName: string;
  date: string;
  time: string;
  oldValue?: string | null;
  newValue?: string | null;
  reason?: string | null;
  details?: string | null;
  createdAt: string;
}

export interface TaskNote {
  id: string;
  taskId: string;
  userId: string;
  userName?: string;
  content: string;
  isInternalOnly: boolean;
  createdAt: string;
  updatedAt: string;
}

export type NotificationType =
  | 'new_task'
  | 'task_assigned'
  | 'status_changed'
  | 'task_delayed'
  | 'task_completed'
  | 'new_note'
  | 'task_updated'
  | 'file_uploaded'
  | 'info'
  | 'security_alert';

export interface TaskAttachment {
  id: string;
  taskId: string;
  uploaderId: string;
  uploaderName?: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  fileUrl: string;
  isPrivate?: boolean;
  fileData?: string;
  createdAt: string;
}

export interface Task {
  id: string;
  taskCode: string;
  companyId: string;
  title: string;
  description?: string;
  assignedToId?: string | null;
  responsiblePersonId?: string | null;
  recipientId?: string | null;
  creatorId: string;
  priority: TaskPrioritySlug;
  status: TaskStatusSlug;
  statusReason?: string | null;
  startDate?: string | null;
  dueDate?: string | null;
  completionDate?: string | null;
  customFields?: Record<string, any>;
  notes?: TaskNote[];
  attachments?: TaskAttachment[];
  timeline?: TaskTimelineEvent[];
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;

  // Compatibility fields
  statusId?: string;
  priorityId?: string;
  assigneeId?: string | null;
  estimatedHours?: number | null;
  actualHours?: number | null;
}

export interface TaskUpdate {
  id: string;
  taskId: string;
  userId: string;
  fieldChanged: string;
  oldValue?: string | null;
  newValue?: string | null;
  comment?: string;
  createdAt: string;
}

export interface CustomFieldValue {
  id: string;
  customFieldId: string;
  entityId: string;
  value: any;
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  companyId?: string | null;
  taskId?: string | null;
  taskCode?: string | null;
  titleEn: string;
  titleAr: string;
  messageEn: string;
  messageAr: string;
  type: NotificationType;
  isRead: boolean;
  actionUrl?: string;
  createdAt: string;
}

export type AuditAction =
  | 'LOGIN'
  | 'LOGOUT'
  | 'CREATE'
  | 'UPDATE'
  | 'DELETE'
  | 'ARCHIVE'
  | 'PERMISSION_CHANGE'
  | 'STATUS_CHANGE'
  | 'USER_CHANGE'
  | 'COMPANY_CHANGE'
  | 'FILE_UPLOAD'
  | 'FILE_DOWNLOAD'
  | string;

export interface AuditLog {
  id: string;
  userId?: string | null;
  userName?: string | null;
  userEmail?: string | null;
  companyId?: string | null;
  companyName?: string | null;
  action: AuditAction;
  entity: string;
  entityId?: string | null;
  oldValue?: string | null;
  newValue?: string | null;
  date: string;
  time: string;
  ipAddress?: string;
  userAgent?: string;
  status: 'SUCCESS' | 'FAILURE' | 'WARNING';
  details?: Record<string, any>;
  createdAt: string;

  // Compatibility fields
  resource?: string;
  resourceId?: string | null;
}

// --- Dashboard Customization Types ---
export type DashboardWidgetKey =
  | 'total_companies'
  | 'total_tasks'
  | 'pending_tasks'
  | 'in_progress_tasks'
  | 'delayed_tasks'
  | 'completed_tasks'
  | 'paused_tasks'
  | 'cancelled_tasks'
  | 'vip_tasks'
  | 'overdue_tasks'
  | 'completion_rate';

export type DashboardChartKey =
  | 'tasks_by_company'
  | 'tasks_by_status'
  | 'tasks_by_priority'
  | 'tasks_by_user'
  | 'tasks_over_time';

export interface DashboardWidgetConfig {
  key: DashboardWidgetKey;
  enabled: boolean;
  order: number;
}

export interface DashboardChartConfig {
  key: DashboardChartKey;
  enabled: boolean;
  order: number;
}

export interface UserDashboardConfig {
  id: string;
  userId: string; // user ID or 'default'
  companyIds: string[]; // ['all'] or specific IDs like ['c1-noor-retail']
  widgets: DashboardWidgetConfig[];
  charts: DashboardChartConfig[];
  showRecentTasks: boolean;
  updatedAt: string;
  updatedBy?: string;
}

export interface CustomAboutSection {
  id: string;
  titleAr: string;
  titleEn: string;
  contentAr: string;
  contentEn: string;
  badge?: string;
  createdAt: string;
}

export interface SystemAboutSettings {
  aboutTitleAr: string;
  aboutTitleEn: string;
  aboutDescriptionAr: string;
  aboutDescriptionEn: string;
  copyrightTextAr: string;
  copyrightTextEn: string;
  developerNameAr: string;
  developerNameEn: string;
  systemVersion: string;
  licenseType: string;
  supportEmail: string;
  customSections?: CustomAboutSection[];
  additionalRights?: string[];
  updatedAt: string;
  updatedBy?: string;
}

export interface BackupConfig {
  autoBackupEnabled: boolean;
  frequency: 'hourly' | 'daily' | 'weekly';
  pathMode: 'auto' | 'manual';
  customPath: string;
  lastBackupAt?: string;
  lastBackupStatus?: 'SUCCESS' | 'FAILED';
  retentionCount: number;
}

export interface BackupMetadata {
  id: string;
  filename: string;
  filePath: string;
  pathMode: 'auto' | 'manual';
  createdAt: string;
  sizeBytes: number;
  companiesCount: number;
  usersCount: number;
  tasksCount: number;
  triggeredBy: string;
  type: 'manual' | 'auto';
}
