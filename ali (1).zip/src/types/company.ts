import { Company, CompanyMetrics, User } from './database';

export interface CompanyWithMetrics extends Company {
  metrics: CompanyMetrics;
  manager?: User | { id: string; fullName: string; fullNameAr?: string; email: string };
}

export interface CompanyContextType {
  activeCompany: Company | null;
  availableCompanies: CompanyWithMetrics[];
  allCompanies: CompanyWithMetrics[];
  isLoading: boolean;
  setActiveCompany: (company: Company) => void;
  refreshCompanies: () => Promise<void>;
  createCompany: (companyData: Partial<Company>) => Promise<Company>;
  updateCompany: (id: string, companyData: Partial<Company>) => Promise<Company>;
  archiveCompany: (id: string, permanent?: boolean) => Promise<void>;
}
