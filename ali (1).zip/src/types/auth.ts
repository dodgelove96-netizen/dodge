import { User, Role, Company } from './database';
import { PermissionKey } from './permissions';

export interface AuthUser extends Omit<User, 'passwordHash'> {
  roles: Role[];
  permissions: PermissionKey[];
  assignedCompanies: Company[];
  primaryCompanyId?: string;
  isSuperAdmin: boolean;
}

export interface LoginResponse {
  token: string;
  user: AuthUser;
}

export interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password?: string) => Promise<void>;
  logout: () => Promise<void>;
  hasPermission: (permission: PermissionKey) => boolean;
  canAccessCompany: (companyId: string) => boolean;
  switchRolePersona: (persona: 'super_admin' | 'admin' | 'manager_owner') => Promise<void>;
}
