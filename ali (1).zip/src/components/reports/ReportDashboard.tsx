import React, { useState, useEffect, useCallback } from 'react';
import { useI18n } from '../../i18n/I18nContext';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { PermissionKey } from '../../types/permissions';
import {
  ReportType,
  ReportFilterParams,
  ReportQueryResult,
  ReportExportFieldKey,
  REPORT_EXPORT_FIELDS,
} from '../../types/reports';
import { Company, User } from '../../types/database';
import { ReportFilters } from './ReportFilters';
import { SelectFieldsModal } from './SelectFieldsModal';
import { PrintableReportView } from './PrintableReportView';
import { generateReportPdf } from '../../utils/pdfExport';
import {
  Building2,
  CheckSquare,
  CheckCircle2,
  AlertTriangle,
  UserCheck,
  Clock,
  Sparkles,
  Download,
  FileSpreadsheet,
  FileText,
  Printer,
  RefreshCw,
  Layers,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  BarChart3,
  Calendar,
} from 'lucide-react';

const REPORT_TABS: Array<{ id: ReportType; key: string; icon: any }> = [
  { id: 'company_report', key: 'reports.tab_company', icon: Building2 },
  { id: 'task_report', key: 'reports.tab_task', icon: CheckSquare },
  { id: 'status_report', key: 'reports.tab_status', icon: Layers },
  { id: 'priority_report', key: 'reports.tab_priority', icon: AlertTriangle },
  { id: 'user_report', key: 'reports.tab_user', icon: UserCheck },
  { id: 'overdue_report', key: 'reports.tab_overdue', icon: Clock },
  { id: 'completion_report', key: 'reports.tab_completion', icon: CheckCircle2 },
];

export const ReportDashboard: React.FC = () => {
  const { t, language } = useI18n();
  const { hasPermission, user } = useAuth();
  const isAr = language === 'ar';

  const [activeReportType, setActiveReportType] = useState<ReportType>('company_report');
  const [filters, setFilters] = useState<ReportFilterParams>({});
  const [reportData, setReportData] = useState<ReportQueryResult | null>(null);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Field Selection Modal State
  const [isFieldModalOpen, setIsFieldModalOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<'excel' | 'pdf'>('excel');

  // Printable Document Preview Modal State
  const [isPrintPreviewOpen, setIsPrintPreviewOpen] = useState(false);
  const [selectedFieldsForPrint, setSelectedFieldsForPrint] = useState<ReportExportFieldKey[]>(() =>
    REPORT_EXPORT_FIELDS.filter(f => f.defaultSelected).map(f => f.key)
  );

  // Fetch reference metadata (companies and users)
  useEffect(() => {
    async function fetchMetadata() {
      try {
        const [compRes, usersRes] = await Promise.all([
          api.getCompanies(),
          api.getUsers(),
        ]);
        setCompanies(compRes.companies || []);
        setUsers(usersRes.users || []);
      } catch (err: any) {
        console.error('Failed to load companies/users for reports:', err);
      }
    }
    fetchMetadata();
  }, []);

  // Fetch report data from authoritative backend
  const loadReportData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await api.queryReports(activeReportType, filters);
      setReportData(data);
    } catch (err: any) {
      console.error('Report query failed:', err);
      setError(err.message || 'Failed to query report data');
    } finally {
      setIsLoading(false);
    }
  }, [activeReportType, filters]);

  useEffect(() => {
    loadReportData();
  }, [loadReportData]);

  const handleResetFilters = () => {
    setFilters({});
  };

  const handleOpenExportModal = (format: 'excel' | 'pdf') => {
    setExportFormat(format);
    setIsFieldModalOpen(true);
  };

  const handleConfirmExport = async (selectedFields: ReportExportFieldKey[]) => {
    if (!reportData) return;
    setIsExporting(true);
    try {
      if (exportFormat === 'excel') {
        await api.exportReportExcel({
          reportType: activeReportType,
          filters,
          selectedFields,
          language: isAr ? 'ar' : 'en',
        });
        setIsFieldModalOpen(false);
      } else {
        // PDF Export
        setSelectedFieldsForPrint(selectedFields);
        setIsFieldModalOpen(false);

        // Generate and download client PDF via jspdf
        generateReportPdf(reportData, selectedFields, isAr);

        // Log backend audit
        await api.exportReportPdfData({
          reportType: activeReportType,
          filters,
          selectedFields,
        });
      }
    } catch (err: any) {
      alert(`Export failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsExporting(false);
    }
  };

  const handleOpenPrintPreview = () => {
    setIsPrintPreviewOpen(true);
  };

  const canExport = hasPermission(PermissionKey.REPORTS_EXPORT) || user?.isSuperAdmin;

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800">
              {isAr ? 'نظام التقارير والرقابة التشغيلية' : 'Executive Reporting Engine'}
            </span>
            <span className="text-xs font-medium text-slate-400">•</span>
            <span className="text-xs font-medium text-slate-500">
              {isAr ? 'معتمد ومحمي بالصلاحيات' : 'Audited & RBAC Protected'}
            </span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">{t('reports.title')}</h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">{t('reports.subtitle')}</p>
        </div>

        {/* Global Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={loadReportData}
            disabled={isLoading}
            className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
            title={t('action.refresh')}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-blue-600' : ''}`} />
          </button>

          <button
            type="button"
            onClick={handleOpenPrintPreview}
            disabled={isLoading || !reportData}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs shadow-xs transition-all flex items-center gap-2"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>{t('reports.print_report')}</span>
          </button>

          {canExport && (
            <>
              <button
                type="button"
                onClick={() => handleOpenExportModal('excel')}
                disabled={isLoading || !reportData || reportData.tasks.length === 0}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 active:scale-95 disabled:opacity-50 disabled:pointer-events-none"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>{t('reports.export_excel')}</span>
              </button>

              <button
                type="button"
                onClick={() => handleOpenExportModal('pdf')}
                disabled={isLoading || !reportData || reportData.tasks.length === 0}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md shadow-rose-600/20 transition-all flex items-center gap-2 active:scale-95 disabled:opacity-50 disabled:pointer-events-none"
              >
                <FileText className="w-4 h-4" />
                <span>{t('reports.export_pdf')}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* 7 Report Types Tab Navigation Bar */}
      <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-sm overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-1.5 min-w-max">
          {REPORT_TABS.map(tab => {
            const Icon = tab.icon;
            const isActive = activeReportType === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveReportType(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/25 scale-[1.02]'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{t(tab.key)}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Advanced Multi-Filters Component */}
      <ReportFilters
        filters={filters}
        onChangeFilters={setFilters}
        onApply={loadReportData}
        onReset={handleResetFilters}
        companies={companies}
        users={users}
        totalMatches={reportData?.tasks.length || 0}
        isLoading={isLoading}
      />

      {/* Error Message */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-3 text-rose-800 text-sm">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-600" />
          <p className="font-semibold">{error}</p>
        </div>
      )}

      {/* KPI Summary Cards */}
      {reportData && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              {t('reports.total_tasks')}
            </span>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-slate-900">{reportData.summary.totalTasks}</span>
              <span className="text-xs font-semibold text-slate-400">
                {isAr ? 'سجل' : 'records'}
              </span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-emerald-200/80 shadow-sm bg-gradient-to-br from-white to-emerald-50/30">
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider block mb-1">
              {t('reports.completed_tasks')}
            </span>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-emerald-700">{reportData.summary.completedTasks}</span>
              <span className="text-xs font-bold text-emerald-600">{reportData.summary.completionRate}%</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-blue-200/80 shadow-sm bg-gradient-to-br from-white to-blue-50/30">
            <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block mb-1">
              {t('reports.in_progress_tasks')}
            </span>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-blue-700">{reportData.summary.inProgressTasks}</span>
              <span className="text-xs font-semibold text-blue-500">
                {isAr ? 'نشطة' : 'active'}
              </span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-amber-200/80 shadow-sm bg-gradient-to-br from-white to-amber-50/30">
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block mb-1">
              {t('reports.delayed_tasks')}
            </span>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-amber-700">{reportData.summary.delayedTasks}</span>
              <span className="text-xs font-semibold text-amber-600">
                {reportData.summary.totalTasks > 0
                  ? Math.round((reportData.summary.delayedTasks / reportData.summary.totalTasks) * 100)
                  : 0}
                %
              </span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-rose-200/80 shadow-sm bg-gradient-to-br from-white to-rose-50/30">
            <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider block mb-1">
              {t('reports.overdue_tasks')}
            </span>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-rose-700">{reportData.summary.overdueTasks}</span>
              <span className="text-xs font-bold text-rose-600">
                {isAr ? 'حرجة' : 'critical'}
              </span>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 border border-purple-200/80 shadow-sm bg-gradient-to-br from-white to-purple-50/30">
            <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wider block mb-1">
              {t('reports.completion_rate')}
            </span>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-black text-purple-700">{reportData.summary.completionRate}%</span>
              <span className="text-xs font-semibold text-purple-500">
                {reportData.summary.avgTurnaroundDays ? `${reportData.summary.avgTurnaroundDays}d avg` : 'SLA'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Group Breakdown Section */}
      {reportData?.groupBreakdown && reportData.groupBreakdown.length > 0 && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              <h3 className="font-bold text-slate-900 text-sm">{t('reports.breakdown_title')}</h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {reportData.groupBreakdown.length} {isAr ? 'عناصر تحليلية' : 'segments'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {reportData.groupBreakdown.map(item => (
              <div
                key={item.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-xs transition-all bg-slate-50/50 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="font-bold text-slate-900 text-sm leading-tight">
                      {isAr ? item.labelAr : item.labelEn}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200/70 text-slate-700 font-mono">
                      {item.key}
                    </span>
                  </div>
                  {item.subLabel && (
                    <p className="text-xs text-slate-500 mb-3">{item.subLabel}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600">{isAr ? 'المهام الإجمالية:' : 'Total Tasks:'}</span>
                    <span className="font-black text-slate-900">{item.total}</span>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden flex">
                    <div
                      style={{ width: `${item.completionRate}%` }}
                      className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                      title={`Completed: ${item.completionRate}%`}
                    />
                    {item.delayed > 0 && item.total > 0 && (
                      <div
                        style={{ width: `${Math.round((item.delayed / item.total) * 100)}%` }}
                        className="bg-amber-500 h-full"
                        title={`Delayed: ${item.delayed}`}
                      />
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <span className="text-emerald-700 font-semibold">
                      {isAr ? `إنجاز: ${item.completionRate}%` : `Done: ${item.completionRate}%`}
                    </span>
                    {item.overdue > 0 && (
                      <span className="text-rose-600 font-bold">
                        {isAr ? `متأخر: ${item.overdue}` : `Overdue: ${item.overdue}`}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filtered Records Data Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/70">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 text-sm">{t('reports.records_table_title')}</h3>
              {reportData && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-600 text-white font-mono">
                  {reportData.tasks.length}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {isAr
                ? 'السجلات الفعلية المفلترة الجاهزة للتصدير والتحليل والمطابقة'
                : 'Authoritative data records strictly matching your active filter criteria'}
            </p>
          </div>

          <div className="text-xs font-semibold text-slate-500">
            {reportData?.appliedFilters.companyName && (
              <span>{reportData.appliedFilters.companyName} • </span>
            )}
            <span>{isAr ? 'بيانات مؤكدة من الخادم' : 'Server-Verified Authenticity'}</span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-100/70 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                <th className="p-3.5 text-start">{isAr ? 'المعرف' : 'Task ID'}</th>
                <th className="p-3.5 text-start">{isAr ? 'العنوان' : 'Title'}</th>
                <th className="p-3.5 text-start">{isAr ? 'الشركة' : 'Company'}</th>
                <th className="p-3.5 text-start">{isAr ? 'المسؤول' : 'Assigned To'}</th>
                <th className="p-3.5 text-start">{isAr ? 'الحالة' : 'Status'}</th>
                <th className="p-3.5 text-start">{isAr ? 'الأولوية' : 'Priority'}</th>
                <th className="p-3.5 text-start">{isAr ? 'تاريخ الاستحقاق' : 'Due Date'}</th>
                <th className="p-3.5 text-start">{isAr ? 'الإنشاء' : 'Created'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
                      <span className="text-xs font-medium text-slate-500">
                        {isAr ? 'جاري استخراج وتجميع بيانات التقرير...' : 'Compiling report records...'}
                      </span>
                    </div>
                  </td>
                </tr>
              ) : !reportData || reportData.tasks.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-slate-400 font-medium">
                    <div className="max-w-sm mx-auto flex flex-col items-center gap-2">
                      <Clock className="w-8 h-8 text-slate-300" />
                      <p className="font-semibold text-slate-700">{t('reports.no_records_found')}</p>
                      <p className="text-xs text-slate-400">
                        {isAr ? 'جرب تغيير أو إزالة بعض الفلاتر لعرض نتائج أوسع' : 'Try adjusting your filters'}
                      </p>
                      <button
                        type="button"
                        onClick={handleResetFilters}
                        className="mt-2 text-xs font-bold text-blue-600 hover:text-blue-800"
                      >
                        {t('reports.clear_filters')}
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                reportData.tasks.map((task, idx) => (
                  <tr key={task.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-blue-700 whitespace-nowrap">
                      {task.taskCode}
                    </td>
                    <td className="p-3.5 font-semibold text-slate-900 max-w-xs">
                      <div className="truncate" title={task.title}>
                        {task.title}
                      </div>
                      {task.statusReason && (
                        <p className="text-[10px] text-amber-700 line-clamp-1 mt-0.5 font-normal">
                          {task.statusReason}
                        </p>
                      )}
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">
                        {isAr ? task.companyNameAr : task.companyNameEn}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">({task.companyCode})</span>
                    </td>
                    <td className="p-3.5 whitespace-nowrap text-slate-700">
                      {isAr ? task.assignedToNameAr || task.assignedToName : task.assignedToName}
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          task.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : task.status === 'delayed'
                            ? 'bg-amber-100 text-amber-800'
                            : task.status === 'in_progress'
                            ? 'bg-blue-100 text-blue-800'
                            : task.status === 'paused'
                            ? 'bg-slate-100 text-slate-700'
                            : task.status === 'cancelled'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {isAr ? task.statusLabelAr : task.statusLabelEn}
                      </span>
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          task.priority === 'vip'
                            ? 'bg-rose-100 text-rose-800'
                            : task.priority === 'high'
                            ? 'bg-orange-100 text-orange-800'
                            : task.priority === 'medium'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {isAr ? task.priorityLabelAr : task.priorityLabelEn}
                      </span>
                    </td>
                    <td className="p-3.5 whitespace-nowrap">
                      <span
                        className={`font-mono text-xs ${
                          task.daysOverdue > 0 ? 'text-rose-600 font-black' : 'text-slate-600'
                        }`}
                      >
                        {task.dueDate || '-'}
                      </span>
                      {task.daysOverdue > 0 && (
                        <span className="block text-[10px] text-rose-600 font-bold">
                          +{task.daysOverdue} {isAr ? 'يوم تأخير' : 'days overdue'}
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 whitespace-nowrap text-slate-500 font-mono text-[11px]">
                      {task.createdAt}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Field Selection Modal before Exporting */}
      <SelectFieldsModal
        isOpen={isFieldModalOpen}
        onClose={() => setIsFieldModalOpen(false)}
        exportFormat={exportFormat}
        totalFilteredRecords={reportData?.tasks.length || 0}
        onConfirm={handleConfirmExport}
        isLoading={isExporting}
      />

      {/* Printable Report Document Preview */}
      {reportData && (
        <PrintableReportView
          isOpen={isPrintPreviewOpen}
          onClose={() => setIsPrintPreviewOpen(false)}
          reportData={reportData}
          selectedFields={selectedFieldsForPrint}
          onDownloadPdfFile={() => generateReportPdf(reportData, selectedFieldsForPrint, isAr)}
        />
      )}
    </div>
  );
};
