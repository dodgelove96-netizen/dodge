import React, { useState, useEffect } from 'react';
import { I18nProvider, useI18n } from './i18n/I18nContext';
import { ToastProvider } from './context/ToastContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CompanyProvider } from './context/CompanyContext';
import { Header } from './components/common/Header';
import { Sidebar, TabType } from './components/common/Sidebar';
import { OverviewDashboard } from './components/dashboard/OverviewDashboard';
import { CompanyList } from './components/companies/CompanyList';
import { TaskList } from './components/tasks/TaskList';
import { CustomFieldManager } from './components/tasks/CustomFieldManager';
import { PermissionMatrix } from './components/permissions/PermissionMatrix';
import { UserManagement } from './components/users/UserManagement';
import { SchemaExplorer } from './components/schema/SchemaExplorer';
import { AuditLogViewer } from './components/audit/AuditLogViewer';
import { ReportDashboard } from './components/reports/ReportDashboard';
import { NotificationCenter } from './components/common/NotificationCenter';
import { SettingsView } from './components/settings/SettingsView';
import { AboutView } from './components/about/AboutView';
import { TaskDetailModal } from './components/tasks/TaskDetailModal';
import { LoginForm } from './components/auth/LoginForm';
import { api } from './services/api';
import { Award, Shield, Layers, Globe } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const { t, language } = useI18n();
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [selectedTaskIdForModal, setSelectedTaskIdForModal] = useState<string | null>(null);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const [copyrightText, setCopyrightText] = useState('حقوق النظام محفوظة للمهندس علي أحمد عنيد');

  useEffect(() => {
    let mounted = true;
    api
      .getSystemAbout()
      .then((res) => {
        if (mounted && res.about) {
          setCopyrightText(
            language === 'ar' ? res.about.copyrightTextAr : res.about.copyrightTextEn
          );
        }
      })
      .catch(() => {});
    return () => {
      mounted = false;
    };
  }, [language, activeTab]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-semibold text-slate-600">
            {language === 'ar'
              ? 'جاري تشغيل وتهيئة منظومة إدارة الشركات...'
              : 'Initializing Enterprise Multi-Company Workspace...'}
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900">
      <Header
        onSelectTask={(taskId) => setSelectedTaskIdForModal(taskId)}
        onOpenMobileNav={() => setIsMobileNavOpen(true)}
        onNavigateTab={(tab) => setActiveTab(tab)}
      />

      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex-1 flex flex-col lg:flex-row gap-6">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          isOpenMobile={isMobileNavOpen}
          onCloseMobile={() => setIsMobileNavOpen(false)}
        />

        <main className="flex-1 min-w-0">
          {activeTab === 'overview' && <OverviewDashboard onNavigate={setActiveTab} />}
          {activeTab === 'companies' && <CompanyList />}
          {activeTab === 'tasks' && <TaskList />}
          {activeTab === 'reports' && <ReportDashboard />}
          {activeTab === 'notifications' && (
            <NotificationCenter onSelectTask={(taskId) => setSelectedTaskIdForModal(taskId)} />
          )}
          {activeTab === 'customFields' && <CustomFieldManager />}
          {activeTab === 'permissions' && (user?.isSuperAdmin ? <PermissionMatrix /> : <OverviewDashboard onNavigate={setActiveTab} />)}
          {activeTab === 'users' && (user?.isSuperAdmin ? <UserManagement /> : <OverviewDashboard onNavigate={setActiveTab} />)}
          {activeTab === 'schema' && (user?.isSuperAdmin ? <SchemaExplorer /> : <OverviewDashboard onNavigate={setActiveTab} />)}
          {activeTab === 'audit' && (user?.isSuperAdmin ? <AuditLogViewer /> : <OverviewDashboard onNavigate={setActiveTab} />)}
          {activeTab === 'settings' && (user?.isSuperAdmin ? <SettingsView /> : <OverviewDashboard onNavigate={setActiveTab} />)}
          {activeTab === 'about' && <AboutView />}
        </main>
      </div>

      {/* Enterprise Platform Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="font-bold text-slate-800 tracking-tight">
              {copyrightText}
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-medium">
            <button
              onClick={() => setActiveTab('about')}
              className="hover:text-blue-600 transition-colors font-semibold"
            >
              {t('nav.about')}
            </button>
            <span>•</span>
            <button
              onClick={() => setActiveTab('settings')}
              className="hover:text-blue-600 transition-colors font-semibold"
            >
              {t('nav.settings')}
            </button>
            <span>•</span>
            <span className="text-slate-400">Enterprise v2.5.0</span>
          </div>
        </div>
      </footer>

      {selectedTaskIdForModal && (
        <TaskDetailModal
          taskId={selectedTaskIdForModal}
          onClose={() => setSelectedTaskIdForModal(null)}
          onTaskUpdated={() => {}}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <I18nProvider>
      <ToastProvider>
        <AuthProvider>
          <CompanyProvider>
            <MainLayout />
          </CompanyProvider>
        </AuthProvider>
      </ToastProvider>
    </I18nProvider>
  );
}
