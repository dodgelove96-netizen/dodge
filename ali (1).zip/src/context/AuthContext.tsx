import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthUser, AuthContextType } from '../types/auth';
import { PermissionKey } from '../types/permissions';
import { api } from '../services/api';

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('auth_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const initAuth = async () => {
    const savedToken = localStorage.getItem('auth_token');
    if (!savedToken) {
      // Auto bootstrap login with Super Admin for seamless preview experience
      try {
        const res = await api.switchPersona('super_admin');
        setToken(res.token);
        setUser(res.user);
        localStorage.setItem('auth_token', res.token);
        if (res.user.assignedCompanies?.[0]) {
          localStorage.setItem('active_company_id', res.user.assignedCompanies[0].id);
        }
      } catch (err: any) {
        console.error('Failed to auto-bootstrap session:', err);
      } finally {
        setIsLoading(false);
      }
      return;
    }

    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch (err: any) {
      console.warn('Session token expired or invalid, clearing:', err);
      localStorage.removeItem('auth_token');
      setToken(null);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    initAuth();
  }, []);

  const login = async (email: string, password?: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.login(email, password);
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('auth_token', res.token);
      if (res.user.assignedCompanies?.[0]) {
        localStorage.setItem('active_company_id', res.user.assignedCompanies[0].id);
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch (e) {
      console.warn('Backend logout notification failed, clearing local session:', e);
    } finally {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('active_company_id');
      setToken(null);
      setUser(null);
    }
  };

  const switchRolePersona = async (persona: 'super_admin' | 'admin' | 'manager_owner') => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.switchPersona(persona);
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('auth_token', res.token);
      if (res.user.assignedCompanies?.[0]) {
        localStorage.setItem('active_company_id', res.user.assignedCompanies[0].id);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to switch persona');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const hasPermission = (permission: PermissionKey): boolean => {
    if (!user) return false;
    if (user.isSuperAdmin) return true;
    return user.permissions.includes(permission);
  };

  const canAccessCompany = (companyId: string): boolean => {
    if (!user) return false;
    if (user.isSuperAdmin) return true;
    return user.assignedCompanies.some(c => c.id === companyId);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        error,
        login,
        logout,
        hasPermission,
        canAccessCompany,
        switchRolePersona,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
