import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Company } from '../types/database';
import { CompanyContextType, CompanyWithMetrics } from '../types/company';
import { api } from '../services/api';
import { useAuth } from './AuthContext';

const CompanyContext = createContext<CompanyContextType | null>(null);

export const CompanyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [activeCompany, setActiveCompanyState] = useState<Company | null>(null);
  const [availableCompanies, setAvailableCompanies] = useState<CompanyWithMetrics[]>([]);
  const [allCompanies, setAllCompanies] = useState<CompanyWithMetrics[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const loadCompanies = useCallback(async () => {
    if (!isAuthenticated || !user) return;
    setIsLoading(true);
    try {
      const res = await api.getCompanies();
      const list = (res.companies || []) as CompanyWithMetrics[];
      setAvailableCompanies(list);
      setAllCompanies(list);

      const savedCompanyId = localStorage.getItem('active_company_id');
      const found = list.find(c => c.id === savedCompanyId);

      if (found) {
        setActiveCompanyState(found);
      } else if (list.length > 0) {
        setActiveCompanyState(list[0]);
        localStorage.setItem('active_company_id', list[0].id);
      } else {
        setActiveCompanyState(null);
      }
    } catch (err) {
      console.error('Failed to load companies:', err);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated, user]);

  useEffect(() => {
    loadCompanies();
  }, [loadCompanies]);

  const setActiveCompany = (company: Company) => {
    setActiveCompanyState(company);
    localStorage.setItem('active_company_id', company.id);
  };

  const refreshCompanies = async () => {
    await loadCompanies();
  };

  const createCompany = async (companyData: Partial<Company>): Promise<Company> => {
    const res = await api.createCompany(companyData);
    await refreshCompanies();
    setActiveCompany(res.company);
    return res.company;
  };

  const updateCompany = async (id: string, companyData: Partial<Company>): Promise<Company> => {
    const res = await api.updateCompany(id, companyData);
    await refreshCompanies();
    if (activeCompany?.id === id) {
      setActiveCompany(res.company);
    }
    return res.company;
  };

  const archiveCompany = async (id: string, permanent = false): Promise<void> => {
    await api.archiveCompany(id, permanent);
    await refreshCompanies();
  };

  return (
    <CompanyContext.Provider
      value={{
        activeCompany,
        availableCompanies,
        allCompanies,
        isLoading,
        setActiveCompany,
        refreshCompanies,
        createCompany,
        updateCompany,
        archiveCompany,
      }}
    >
      {children}
    </CompanyContext.Provider>
  );
};

export const useCompany = (): CompanyContextType => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error('useCompany must be used within a CompanyProvider');
  }
  return context;
};
