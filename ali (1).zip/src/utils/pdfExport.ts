import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ReportQueryResult, ReportExportFieldKey, REPORT_EXPORT_FIELDS } from '../types/reports';

export function generateReportPdf(
  reportData: ReportQueryResult,
  selectedFields: ReportExportFieldKey[],
  isAr = false
): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'pt',
    format: 'a4',
  });

  const title = isAr ? 'تقرير المهام والمؤشرات التشغيلية للمجموعة' : 'Enterprise Operations & Tasks Report';
  const subtitle = `${isAr ? 'تاريخ التوليد:' : 'Generated on:'} ${new Date().toLocaleString()} | ${isAr ? 'إجمالي السجلات:' : 'Total Records:'} ${reportData.filteredCount}`;

  // Header
  doc.setFontSize(16);
  doc.text(title, 40, 40);
  doc.setFontSize(10);
  doc.text(subtitle, 40, 58);

  const fieldDefs = REPORT_EXPORT_FIELDS.filter(f => selectedFields.includes(f.key));
  const headers = [fieldDefs.map(f => (isAr ? f.labelAr : f.labelEn))];

  const rows = (reportData.data || []).map((row: any) => {
    return fieldDefs.map(f => {
      const val = row[f.key];
      if (val === undefined || val === null) return '-';
      if (typeof val === 'object') return JSON.stringify(val);
      return String(val);
    });
  });

  autoTable(doc, {
    head: headers,
    body: rows,
    startY: 75,
    styles: {
      fontSize: 8,
      cellPadding: 4,
    },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: 255,
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
  });

  doc.save(`Operations_Report_${new Date().toISOString().substring(0, 10)}.pdf`);
}
