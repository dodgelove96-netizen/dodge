import { Router, Response } from 'express';
import * as XLSX from 'xlsx';
import { dbStorage } from '../db/storage';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth';
import { requirePermission } from '../middleware/permissions';
import { PermissionKey } from '../../types/permissions';
import { REPORT_EXPORT_FIELDS, ReportQueryResult } from '../../types/reports';

export const reportRouter = Router();

reportRouter.get('/query', requireAuth, requirePermission(PermissionKey.REPORTS_VIEW), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const {
      reportType = 'tasks',
      companyId,
      status,
      priority,
      assignedToId,
      creatorId,
      dateFrom,
      dateTo,
      dueDateFrom,
      dueDateTo,
      search,
    } = req.query;

    const allowedCompanyIds = user.isSuperAdmin
      ? undefined
      : user.assignedCompanies?.map(c => c.id) || [];

    const allTasks = dbStorage.getTasks({
      companyId: companyId as string,
      status: status as string,
      priority: priority as string,
      assigneeId: assignedToId as string,
      search: search as string,
      allowedCompanyIds,
    });

    let filtered = allTasks;

    if (creatorId && creatorId !== 'all') {
      filtered = filtered.filter(t => t.creatorId === creatorId);
    }
    if (dateFrom) {
      filtered = filtered.filter(t => new Date(t.createdAt) >= new Date(dateFrom as string));
    }
    if (dateTo) {
      filtered = filtered.filter(t => new Date(t.createdAt) <= new Date(dateTo as string));
    }
    if (dueDateFrom) {
      filtered = filtered.filter(t => t.dueDate && new Date(t.dueDate) >= new Date(dueDateFrom as string));
    }
    if (dueDateTo) {
      filtered = filtered.filter(t => t.dueDate && new Date(t.dueDate) <= new Date(dueDateTo as string));
    }

    const formattedData = filtered.map((t: any) => ({
      ...t,
      companyName: t.company?.nameAr || t.company?.nameEn || '',
      status: t.status?.nameAr || t.status?.nameEn || t.status || '',
      priority: t.priority?.nameAr || t.priority?.nameEn || t.priority || '',
      assigneeName: t.assignedTo?.fullName || t.assignee?.fullName || 'غير مسند',
      creatorName: t.creator?.fullName || '',
    }));

    const result: ReportQueryResult = {
      data: formattedData,
      totalCount: allTasks.length,
      filteredCount: formattedData.length,
      metrics: {
        total: formattedData.length,
        completed: formattedData.filter(t => t.statusSlug === 'completed' || t.statusId === 'ts-5').length,
      },
      generatedAt: new Date().toISOString(),
      filters: req.query as any,
    };

    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to query reports' });
  }
});

reportRouter.post('/export/excel', requireAuth, requirePermission(PermissionKey.REPORTS_EXPORT), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { reportType = 'tasks', filters = {}, selectedFields = [], language = 'ar' } = req.body;
    const isAr = language === 'ar';

    const user = req.user!;
    const allowedCompanyIds = user.isSuperAdmin
      ? undefined
      : user.assignedCompanies?.map(c => c.id) || [];

    const tasks = dbStorage.getTasks({
      companyId: filters.companyId,
      status: filters.status,
      priority: filters.priority,
      assigneeId: filters.assignedToId || filters.assigneeId,
      search: filters.search,
      allowedCompanyIds,
    });

    const fieldDefs = REPORT_EXPORT_FIELDS.filter(f => selectedFields.length === 0 || selectedFields.includes(f.key));

    const rows = tasks.map((t: any) => {
      const row: Record<string, any> = {};
      fieldDefs.forEach(field => {
        const header = isAr ? field.labelAr : field.labelEn;
        if (field.key === 'companyName') row[header] = t.company?.nameAr || t.company?.nameEn || '';
        else if (field.key === 'status') row[header] = t.status?.nameAr || t.status?.nameEn || '';
        else if (field.key === 'priority') row[header] = t.priority?.nameAr || t.priority?.nameEn || '';
        else if (field.key === 'assigneeName') row[header] = t.assignedTo?.fullName || 'غير مسند';
        else if (field.key === 'creatorName') row[header] = t.creator?.fullName || '';
        else row[header] = t[field.key] ?? '';
      });
      return row;
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');

    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=report_${reportType}_${Date.now()}.xlsx`);
    res.send(buffer);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to export Excel' });
  }
});

reportRouter.post('/export/pdf-data', requireAuth, requirePermission(PermissionKey.REPORTS_EXPORT), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { filters = {} } = req.body;
    const user = req.user!;
    const allowedCompanyIds = user.isSuperAdmin
      ? undefined
      : user.assignedCompanies?.map(c => c.id) || [];

    const tasks = dbStorage.getTasks({
      companyId: filters.companyId,
      status: filters.status,
      priority: filters.priority,
      assigneeId: filters.assignedToId || filters.assigneeId,
      search: filters.search,
      allowedCompanyIds,
    });

    const formattedData = tasks.map((t: any) => ({
      ...t,
      companyName: t.company?.nameAr || t.company?.nameEn || '',
      status: t.status?.nameAr || t.status?.nameEn || '',
      priority: t.priority?.nameAr || t.priority?.nameEn || '',
      assigneeName: t.assignedTo?.fullName || 'غير مسند',
      creatorName: t.creator?.fullName || '',
    }));

    res.json({
      success: true,
      data: {
        data: formattedData,
        totalCount: formattedData.length,
        filteredCount: formattedData.length,
        generatedAt: new Date().toISOString(),
        filters,
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to export PDF data' });
  }
});
