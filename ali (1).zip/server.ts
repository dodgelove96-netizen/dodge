import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { authRouter } from './src/server/routes/auth.routes';
import { companyRouter } from './src/server/routes/company.routes';
import { roleRouter } from './src/server/routes/role.routes';
import { userRouter } from './src/server/routes/user.routes';
import { auditRouter } from './src/server/routes/audit.routes';
import { notificationRouter } from './src/server/routes/notification.routes';
import { schemaRouter } from './src/server/routes/schema.routes';
import { securityTestRouter } from './src/server/routes/security-test.routes';
import { systemRouter } from './src/server/routes/system.routes';
import { taskRouter } from './src/server/routes/task.routes';
import { customFieldRouter } from './src/server/routes/custom-field.routes';
import { dashboardRouter } from './src/server/routes/dashboard.routes';
import { reportRouter } from './src/server/routes/report.routes';
import { apiRateLimiter } from './src/server/middleware/rateLimit';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser & Cookie Parser
  app.use(express.json());
  app.use(cookieParser());

  // General API Rate Limiting
  app.use('/api', apiRateLimiter);

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString(), version: '2.0.0-phase2' });
  });

  // Register API routes
  app.use('/api/auth', authRouter);
  app.use('/api/companies', companyRouter);
  app.use('/api/tasks', taskRouter);
  app.use('/api/custom-fields', customFieldRouter);
  app.use('/api/dashboard', dashboardRouter);
  app.use('/api/reports', reportRouter);
  app.use('/api/roles', roleRouter);
  app.use('/api/users', userRouter);
  app.use('/api/audit-logs', auditRouter);
  app.use('/api/notifications', notificationRouter);
  app.use('/api/system', systemRouter);
  app.use('/api/system/schema', schemaRouter);
  app.use('/api/security-test', securityTestRouter);

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Enterprise Multi-Company Backend & Dev Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
